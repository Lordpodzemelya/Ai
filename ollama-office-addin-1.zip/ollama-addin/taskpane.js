/* global Office, Word, Excel */

let hostType = null; // "Word" | "Excel"

const els = {};

function $(id) { return document.getElementById(id); }

function setStatus(msg, isError) {
  els.status.textContent = msg || "";
  els.status.className = "status" + (isError ? " error" : "");
}

function getOllamaUrl() {
  return (els.ollamaUrl.value || "http://localhost:11434").replace(/\/+$/, "");
}

function saveSettings() {
  localStorage.setItem("ollamaUrl", els.ollamaUrl.value);
  localStorage.setItem("ollamaModel", els.modelSelect.value);
}

function loadSettings() {
  const savedUrl = localStorage.getItem("ollamaUrl");
  if (savedUrl) els.ollamaUrl.value = savedUrl;
}

async function refreshModels() {
  setStatus("Загрузка списка моделей...");
  try {
    const res = await fetch(getOllamaUrl() + "/api/tags");
    if (!res.ok) throw new Error("HTTP " + res.status);
    const data = await res.json();
    const savedModel = localStorage.getItem("ollamaModel");
    els.modelSelect.innerHTML = "";
    (data.models || []).forEach((m) => {
      const opt = document.createElement("option");
      opt.value = m.name;
      opt.textContent = m.name;
      els.modelSelect.appendChild(opt);
    });
    if (savedModel && [...els.modelSelect.options].some((o) => o.value === savedModel)) {
      els.modelSelect.value = savedModel;
    }
    setStatus("Моделей найдено: " + els.modelSelect.options.length);
  } catch (err) {
    setStatus(
      "Не удалось получить список моделей: " + err.message +
        ". Проверьте адрес и что 'ollama serve' запущена и разрешает CORS для " +
        window.location.origin,
      true
    );
  }
}

async function callOllama(prompt) {
  const model = els.modelSelect.value;
  if (!model) throw new Error("Модель не выбрана");
  const res = await fetch(getOllamaUrl() + "/api/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model, prompt, stream: false }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error("HTTP " + res.status + ": " + text);
  }
  const data = await res.json();
  return data.response || "";
}

// ---------- Word / Excel selection helpers ----------

async function getSelectedText() {
  if (hostType === Office.HostType.Word) {
    return Word.run(async (context) => {
      const range = context.document.getSelection();
      range.load("text");
      await context.sync();
      return range.text;
    });
  } else if (hostType === Office.HostType.Excel) {
    return Excel.run(async (context) => {
      const range = context.workbook.getSelectedRange();
      range.load("values");
      await context.sync();
      return range.values.map((row) => row.join("\t")).join("\n");
    });
  }
  throw new Error("Неизвестный хост Office");
}

async function replaceSelection(text) {
  if (hostType === Office.HostType.Word) {
    return Word.run(async (context) => {
      const range = context.document.getSelection();
      range.insertText(text, Word.InsertLocation.replace);
      await context.sync();
    });
  } else if (hostType === Office.HostType.Excel) {
    return Excel.run(async (context) => {
      const range = context.workbook.getSelectedRange();
      range.values = [[text]];
      await context.sync();
    });
  }
}

async function insertAfterSelection(text) {
  if (hostType === Office.HostType.Word) {
    return Word.run(async (context) => {
      const range = context.document.getSelection();
      range.insertText("\n" + text, Word.InsertLocation.end);
      await context.sync();
    });
  } else if (hostType === Office.HostType.Excel) {
    return Excel.run(async (context) => {
      const range = context.workbook.getSelectedRange();
      const target = range.getOffsetRange(0, 1);
      target.values = [[text]];
      await context.sync();
    });
  }
}

// ---------- Button handlers ----------

async function withBusy(fn) {
  document.querySelectorAll("button").forEach((b) => (b.disabled = true));
  try {
    await fn();
  } catch (err) {
    setStatus("Ошибка: " + err.message, true);
  } finally {
    document.querySelectorAll("button").forEach((b) => (b.disabled = false));
  }
}

function bindEvents() {
  els.settingsToggle.addEventListener("click", () => {
    els.settingsPanel.classList.toggle("hidden");
  });

  els.refreshModels.addEventListener("click", () => withBusy(refreshModels));

  els.ollamaUrl.addEventListener("change", () => {
    saveSettings();
    withBusy(refreshModels);
  });
  els.modelSelect.addEventListener("change", saveSettings);

  els.btnTranslate.addEventListener("click", () =>
    withBusy(async () => {
      const sel = await getSelectedText();
      if (!sel) return setStatus("Ничего не выделено.", true);
      setStatus("Перевожу...");
      const result = await callOllama(
        "Переведи следующий текст на русский язык. Выведи только перевод, без пояснений:\n" + sel
      );
      els.responseBox.value = result;
      setStatus("Готово.");
    })
  );

  els.btnSummarize.addEventListener("click", () =>
    withBusy(async () => {
      const sel = await getSelectedText();
      if (!sel) return setStatus("Ничего не выделено.", true);
      setStatus("Формирую резюме...");
      const result = await callOllama("Сделай краткое резюме следующего текста на русском языке:\n" + sel);
      els.responseBox.value = result;
      setStatus("Готово.");
    })
  );

  els.btnCustomWithSelection.addEventListener("click", () =>
    withBusy(async () => {
      const instruction = els.promptBox.value.trim();
      if (!instruction) return setStatus("Введите инструкцию.", true);
      const sel = await getSelectedText();
      if (!sel) return setStatus("Ничего не выделено.", true);
      setStatus("Обрабатываю...");
      const result = await callOllama(instruction + ":\n\n" + sel);
      els.responseBox.value = result;
      setStatus("Готово.");
    })
  );

  els.btnCustomFree.addEventListener("click", () =>
    withBusy(async () => {
      const instruction = els.promptBox.value.trim();
      if (!instruction) return setStatus("Введите запрос.", true);
      setStatus("Обрабатываю...");
      const result = await callOllama(instruction);
      els.responseBox.value = result;
      setStatus("Готово.");
    })
  );

  els.btnReplace.addEventListener("click", () =>
    withBusy(async () => {
      if (!els.responseBox.value) return setStatus("Нет ответа для вставки.", true);
      await replaceSelection(els.responseBox.value);
      setStatus("Выделенное заменено.");
    })
  );

  els.btnInsertAfter.addEventListener("click", () =>
    withBusy(async () => {
      if (!els.responseBox.value) return setStatus("Нет ответа для вставки.", true);
      await insertAfterSelection(els.responseBox.value);
      setStatus("Ответ вставлен.");
    })
  );
}

Office.onReady((info) => {
  hostType = info.host;
  [
    "hostBadge", "settingsToggle", "settingsPanel", "ollamaUrl", "modelSelect",
    "refreshModels", "settingsStatus", "promptBox", "responseBox", "status",
    "btnTranslate", "btnSummarize", "btnCustomWithSelection", "btnCustomFree",
    "btnReplace", "btnInsertAfter",
  ].forEach((id) => (els[id] = $(id)));

  els.hostBadge.textContent = hostType === Office.HostType.Word ? "Word" : hostType === Office.HostType.Excel ? "Excel" : String(hostType);

  loadSettings();
  bindEvents();
  withBusy(refreshModels);
});
