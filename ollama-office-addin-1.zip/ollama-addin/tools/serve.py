"""
Простой HTTPS-сервер для раздачи файлов Office Add-in с localhost.
Не требует прав администратора, не требует установки пакетов (только стандартная библиотека).

Запуск:
    python serve.py

Раздаёт папку на уровень выше tools/ (корень add-in, где лежит manifest.xml,
taskpane.html и т.д.) по адресу https://localhost:3000/
"""
import http.server
import os
import ssl

PORT = 3000
TOOLS_DIR = os.path.dirname(os.path.abspath(__file__))
ADDIN_DIR = os.path.dirname(TOOLS_DIR)  # папка на уровень выше (корень add-in)
CERT_FILE = os.path.join(TOOLS_DIR, "cert.pem")
KEY_FILE = os.path.join(TOOLS_DIR, "key.pem")


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=ADDIN_DIR, **kwargs)

    def end_headers(self):
        # На случай если taskpane и Ollama окажутся на разных origin'ах —
        # эти заголовки на статику не мешают, а для fetch-запросов к Ollama
        # CORS настраивается на стороне самой Ollama (переменная OLLAMA_ORIGINS).
        self.send_header("Cache-Control", "no-cache")
        super().end_headers()


def main():
    if not (os.path.exists(CERT_FILE) and os.path.exists(KEY_FILE)):
        print("Не найдены cert.pem / key.pem рядом со скриптом.")
        print("Сначала выполните: python gen_cert.py")
        return

    httpd = http.server.HTTPServer(("localhost", PORT), Handler)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(certfile=CERT_FILE, keyfile=KEY_FILE)
    httpd.socket = ctx.wrap_socket(httpd.socket, server_side=True)

    print(f"Раздаю {ADDIN_DIR}")
    print(f"Manifest:  https://localhost:{PORT}/manifest.xml")
    print(f"Taskpane:  https://localhost:{PORT}/taskpane.html")
    print("Ctrl+C для остановки")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
