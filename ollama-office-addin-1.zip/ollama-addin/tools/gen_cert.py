"""
Генерирует self-signed сертификат для https://localhost (без прав администратора).
Создаёт: key.pem, cert.pem (для сервера) и cert.cer (для импорта в Windows,
CurrentUser\\Root — тоже без админ-прав).

Требуется пакет 'cryptography':
    pip install cryptography --break-system-packages
"""
import datetime
import ipaddress
import os

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID

OUT_DIR = os.path.dirname(os.path.abspath(__file__))

key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "localhost")])

cert = (
    x509.CertificateBuilder()
    .subject_name(name)
    .issuer_name(name)
    .public_key(key.public_key())
    .serial_number(x509.random_serial_number())
    .not_valid_before(datetime.datetime.utcnow() - datetime.timedelta(days=1))
    .not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=1825))
    .add_extension(
        x509.SubjectAlternativeName(
            [x509.DNSName("localhost"), x509.IPAddress(ipaddress.ip_address("127.0.0.1"))]
        ),
        critical=False,
    )
    .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
    .sign(key, hashes.SHA256())
)

with open(os.path.join(OUT_DIR, "key.pem"), "wb") as f:
    f.write(
        key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )

with open(os.path.join(OUT_DIR, "cert.pem"), "wb") as f:
    f.write(cert.public_bytes(serialization.Encoding.PEM))

with open(os.path.join(OUT_DIR, "cert.cer"), "wb") as f:
    f.write(cert.public_bytes(serialization.Encoding.DER))

print("Готово. Созданы файлы в", OUT_DIR)
print(" - key.pem, cert.pem  -> для локального HTTPS-сервера (serve.py)")
print(" - cert.cer           -> импортировать в Windows (см. README, без прав администратора)")
