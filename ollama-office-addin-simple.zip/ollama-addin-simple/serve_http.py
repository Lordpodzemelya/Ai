"""
Обычный HTTP-сервер (без HTTPS/сертификата) для упрощённого варианта надстройки.
Только стандартная библиотека, запуск:
    python serve_http.py
Раздаёт https://... нет, именно http://localhost:3000/
"""
import http.server
import os

PORT = 3000
DIR = os.path.dirname(os.path.abspath(__file__))


class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=DIR, **kwargs)


if __name__ == "__main__":
    httpd = http.server.HTTPServer(("localhost", PORT), Handler)
    print(f"Manifest:  http://localhost:{PORT}/manifest.xml")
    print(f"Taskpane:  http://localhost:{PORT}/taskpane.html")
    print("Ctrl+C для остановки")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
