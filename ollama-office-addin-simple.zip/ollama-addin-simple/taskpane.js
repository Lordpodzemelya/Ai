/* global Office, Word, Excel */

let hostType = null; // "Word" | "Excel"

const els = {};

function $(id) { return document.getElementById(id); }

function setStatus(msg, isError) {
  els.status.textContent = msg || "";
  els.status.className = "status" + (isError ? " error" : "");
}

function getOllamaUrl() {
  return (els.ollamaUrl.value || "http://localhost:11434").replace(/\/+$/, "");
}

function saveSettings() {
  localStorage.setItem("ollamaUrl", els.ollamaUrl.value);
  localStorage.setItem("ollamaModel", els.modelSelect.value);
}

function loadSettings() {
  const savedUrl = localStorage.getItem("ollamaUrl");
  if (savedUrl) els.ollamaUrl.value = savedUrl;
}

async function refreshModels() {
  setStatus("Загрузка списка моделей...");
  try {
    const res = await fetch(getOllamaUrl() + "/api/tags");
    if (!res.ok) throw new Error("HTTP " + res.status);
    const data = await res.json();
    const savedModel = localStorage.getItem("ollamaModel");
    els.modelSelect.innerHTML = "";
    (data.models || []).forEach((m) => {
      const opt = document.createElement("option");
      opt.value = m.name;
      opt.textContent = m.name;
      els.modelSelect.appendChild(opt);
    });
    if (savedModel && [...els.modelSelect.options].some((o) => o.value === savedModel)) {
      els.modelSelect.value = savedModel;
    }
    setStatus("Моделей найдено: " + els.modelSelect.options.length);
  } catch (err) {
    setStatus(
      "Не удалось получить список моделей: " + err.message +
        ". Проверьте адрес и что 'ollama serve' запущена и разрешает CORS для " +
        window.location.origin,
      true
    );
  }
}

async function callOllama(prompt) {
  const model = els.modelSelect.value;
  if (!model) throw new Error("Модель не выбрана");
  const res = await fetch(getOllamaUrl() + "/api/generate", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ model, prompt, stream: false }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error("HTTP " + res.status + ": " + text);
  }
  const data = await res.json();
  return data.response || "";
}

// ---------- Word / Excel selection helpers ----------

async function getSelectedText() {
  if (hostType === Office.HostType.Word) {
    return Word.run(async (context) => {
      const range = context.document.getSelection();
      range.load("text");
      await context.sync();
      return range.text;
    });
  } else if (hostType === Office.HostType.Excel) {
    return Excel.run(async (context) => {
      const range = context.workbook.getSelectedRange();
      range.load("values");
      await context.sync();
      return range.values.map((row) => row.join("\t")).join("\n");
    });
  }
  throw new Error("Неизвестный хост Office");
}

async function replaceSelection(text) {
  if (hostType === Office.HostType.Word) {
    return Word.run(async (context) => {
      const range = context.document.getSelection();
      range.insertText(text, Word.InsertLocation.replace);
      await context.sync();
    });
  } else if (hostType === Office.HostType.Excel) {
    return Excel.run(async (context) => {
      const range = context.workbook.getSelectedRange();
      range.values = [[text]];
      await context.sync();
    });
  }
}

async function insertAfterSelection(text) {
  if (hostType === Office.HostType.Word) {
    return Word.run(async (context) => {
      const range = context.document.getSelection();
      range.insertText("\n" + text, Word.InsertLocation.end);
      await context.sync();
    });
  } else if (hostType === Office.HostType.Excel) {
    return Excel.run(async (context) => {
      const range = context.workbook.getSelectedRange();
      const target = range.getOffsetRange(0, 1);
      target.values = [[text]];
      await context.sync();
    });
  }
}

// ---------- Table row context (Word) ----------

let tableContext = null; // { headers: [], values: [], rowIndex, columnIndex }

async function loadTableRowContext() {
  if (hostType !== Office.HostType.Word) {
    throw new Error("Контекст строки таблицы доступен только в Word.");
  }
  return Word.run(async (context) => {
    const cell = context.document.getSelection().parentTableCellOrNullObject;
    cell.load(["rowIndex", "columnIndex"]);
    await context.sync();
    if (cell.isNullObject) {
      throw new Error("Курсор должен быть в ячейке таблицы.");
    }
    const table = cell.parentTableOrNullObject;
    context.load(table, "rowCount");
    await context.sync();
    if (table.isNullObject) {
      throw new Error("Не удалось найти таблицу.");
    }

    const headerRow = table.rows.getItemAt(0);
    headerRow.load("cells/items");
    const currentRow = table.rows.getItemAt(cell.rowIndex);
    currentRow.load("cells/items");
    await context.sync();

    headerRow.cells.items.forEach((c) => c.body.load("text"));
    currentRow.cells.items.forEach((c) => c.body.load("text"));
    await context.sync();

    const headers = headerRow.cells.items.map((c) => (c.body.text || "").trim());
    const values = currentRow.cells.items.map((c) => (c.body.text || "").trim());

    return { headers, values, rowIndex: cell.rowIndex, columnIndex: cell.columnIndex };
  });
}

function formatTableContext(ctx) {
  const lines = ["Заголовки таблицы: " + ctx.headers.join(" | ")];
  lines.push("Текущая строка: " + ctx.values.join(" | "));
  lines.push("Редактируемая ячейка (по счёту в строке, с 0): " + ctx.columnIndex + " — колонка \"" + (ctx.headers[ctx.columnIndex] || "?") + "\"");
  return lines.join("\n");
}

// ---------- Page format / table autofit (Word) ----------

const MM_TO_PT = 72 / 25.4;
const PAPER_SIZES_MM = {
  A3: [297, 420],
  A4: [210, 297],
  A5: [148, 210],
  Letter: [215.9, 279.4],
  Legal: [215.9, 355.6],
};

function requireWord() {
  if (hostType !== Office.HostType.Word) {
    throw new Error("Эта функция доступна только в Word.");
  }
}

async function applyPageFormat(paperKey, orientation, marginsMm) {
  requireWord();
  const [wMm, hMm] = PAPER_SIZES_MM[paperKey] || PAPER_SIZES_MM.A4;
  let widthPt = wMm * MM_TO_PT;
  let heightPt = hMm * MM_TO_PT;
  if (orientation === "landscape" && heightPt > widthPt) {
    [widthPt, heightPt] = [heightPt, widthPt];
  } else if (orientation === "portrait" && widthPt > heightPt) {
    [widthPt, heightPt] = [heightPt, widthPt];
  }
  const marginPt = marginsMm != null ? Number(marginsMm) * MM_TO_PT : null;

  return Word.run(async (context) => {
    const sections = context.document.sections;
    sections.load("items");
    await context.sync();
    sections.items.forEach((s) => {
      s.pageSetup.pageWidth = widthPt;
      s.pageSetup.pageHeight = heightPt;
      if (marginPt != null) {
        s.pageSetup.topMargin = marginPt;
        s.pageSetup.bottomMargin = marginPt;
        s.pageSetup.leftMargin = marginPt;
        s.pageSetup.rightMargin = marginPt;
      }
    });
    await context.sync();
  });
}

async function autofitTables(onlyCurrent) {
  requireWord();
  return Word.run(async (context) => {
    let tables;
    if (onlyCurrent) {
      const cell = context.document.getSelection().parentTableCellOrNullObject;
      await context.sync();
      if (cell.isNullObject) throw new Error("Курсор должен быть внутри таблицы.");
      tables = [cell.parentTableOrNullObject];
    } else {
      const all = context.document.body.tables;
      all.load("items");
      await context.sync();
      tables = all.items;
    }
    tables.forEach((t) => t.autoFitWindow());
    await context.sync();
  });
}

// ---------- Button handlers ----------

async function withBusy(fn) {
  document.querySelectorAll("button").forEach((b) => (b.disabled = true));
  try {
    await fn();
  } catch (err) {
    setStatus("Ошибка: " + err.message, true);
  } finally {
    document.querySelectorAll("button").forEach((b) => (b.disabled = false));
  }
}

function bindEvents() {
  els.settingsToggle.addEventListener("click", () => {
    els.settingsPanel.classList.toggle("hidden");
  });

  els.refreshModels.addEventListener("click", () => withBusy(refreshModels));

  els.ollamaUrl.addEventListener("change", () => {
    saveSettings();
    withBusy(refreshModels);
  });
  els.modelSelect.addEventListener("change", saveSettings);

  els.btnTranslate.addEventListener("click", () =>
    withBusy(async () => {
      const sel = await getSelectedText();
      if (!sel) return setStatus("Ничего не выделено.", true);
      setStatus("Перевожу...");
      const result = await callOllama(
        "Переведи следующий текст на русский язык. Выведи только перевод, без пояснений:\n" + sel
      );
      els.responseBox.value = result;
      setStatus("Готово.");
    })
  );

  els.btnSummarize.addEventListener("click", () =>
    withBusy(async () => {
      const sel = await getSelectedText();
      if (!sel) return setStatus("Ничего не выделено.", true);
      setStatus("Формирую резюме...");
      const result = await callOllama("Сделай краткое резюме следующего текста на русском языке:\n" + sel);
      els.responseBox.value = result;
      setStatus("Готово.");
    })
  );

  els.btnCustomWithSelection.addEventListener("click", () =>
    withBusy(async () => {
      const instruction = els.promptBox.value.trim();
      if (!instruction) return setStatus("Введите инструкцию.", true);
      const sel = await getSelectedText();
      if (!sel) return setStatus("Ничего не выделено.", true);
      setStatus("Обрабатываю...");
      const result = await callOllama(instruction + ":\n\n" + sel);
      els.responseBox.value = result;
      setStatus("Готово.");
    })
  );

  els.btnLoadTableContext.addEventListener("click", () =>
    withBusy(async () => {
      setStatus("Читаю таблицу...");
      tableContext = await loadTableRowContext();
      els.tableContextBox.value = formatTableContext(tableContext);
      els.tableContextPanel.classList.remove("hidden");
      setStatus("Контекст строки загружен.");
    })
  );

  els.btnClearTableContext.addEventListener("click", () => {
    tableContext = null;
    els.tableContextBox.value = "";
    els.tableContextPanel.classList.add("hidden");
    setStatus("Контекст очищен.");
  });

  els.btnCustomWithTableContext.addEventListener("click", () =>
    withBusy(async () => {
      const instruction = els.promptBox.value.trim();
      if (!instruction) return setStatus("Введите инструкцию.", true);
      if (!tableContext) return setStatus("Сначала загрузите контекст строки.", true);
      setStatus("Обрабатываю с учётом контекста строки...");
      const prompt =
        "Ты помогаешь заполнять таблицу технического документа (план управления / PFMEA и т.п.).\n" +
        formatTableContext(tableContext) +
        "\n\nЗадача: " + instruction +
        "\nОтветь только содержимым для ячейки \"" + (tableContext.headers[tableContext.columnIndex] || "текущая ячейка") +
        "\", без пояснений и без повтора остальной строки.";
      const result = await callOllama(prompt);
      els.responseBox.value = result;
      setStatus("Готово.");
    })
  );

  els.btnApplyPageFormat.addEventListener("click", () =>
    withBusy(async () => {
      setStatus("Меняю формат страницы...");
      await applyPageFormat(els.paperSize.value, els.orientation.value, els.marginsMm.value);
      setStatus("Формат страницы применён: " + els.paperSize.value + ", " + els.orientation.value + ", поля " + els.marginsMm.value + "мм.");
    })
  );

  els.btnAutofitCurrentTable.addEventListener("click", () =>
    withBusy(async () => {
      setStatus("Подгоняю текущую таблицу...");
      await autofitTables(true);
      setStatus("Готово.");
    })
  );

  els.btnAutofitAllTables.addEventListener("click", () =>
    withBusy(async () => {
      setStatus("Подгоняю все таблицы в документе...");
      await autofitTables(false);
      setStatus("Готово.");
    })
  );

  els.btnOptimizeA3.addEventListener("click", () =>
    withBusy(async () => {
      setStatus("Применяю А3, альбомная, поля 10мм...");
      await applyPageFormat("A3", "landscape", 10);
      setStatus("Подгоняю все таблицы под новую ширину страницы...");
      await autofitTables(false);
      els.paperSize.value = "A3";
      els.orientation.value = "landscape";
      els.marginsMm.value = "10";
      setStatus("Готово: А3, альбомная, поля 10мм, таблицы подогнаны.");
    })
  );

  els.btnCustomFree.addEventListener("click", () =>
    withBusy(async () => {
      const instruction = els.promptBox.value.trim();
      if (!instruction) return setStatus("Введите запрос.", true);
      setStatus("Обрабатываю...");
      const result = await callOllama(instruction);
      els.responseBox.value = result;
      setStatus("Готово.");
    })
  );

  els.btnReplace.addEventListener("click", () =>
    withBusy(async () => {
      if (!els.responseBox.value) return setStatus("Нет ответа для вставки.", true);
      await replaceSelection(els.responseBox.value);
      setStatus("Выделенное заменено.");
    })
  );

  els.btnInsertAfter.addEventListener("click", () =>
    withBusy(async () => {
      if (!els.responseBox.value) return setStatus("Нет ответа для вставки.", true);
      await insertAfterSelection(els.responseBox.value);
      setStatus("Ответ вставлен.");
    })
  );
}

Office.onReady((info) => {
  hostType = info.host;
  [
    "hostBadge", "settingsToggle", "settingsPanel", "ollamaUrl", "modelSelect",
    "refreshModels", "settingsStatus", "promptBox", "responseBox", "status",
    "btnTranslate", "btnSummarize", "btnCustomWithSelection", "btnCustomFree",
    "btnReplace", "btnInsertAfter",
    "btnLoadTableContext", "btnClearTableContext", "btnCustomWithTableContext",
    "tableContextPanel", "tableContextBox",
    "paperSize", "orientation", "marginsMm",
    "btnApplyPageFormat", "btnAutofitCurrentTable", "btnAutofitAllTables", "btnOptimizeA3",
  ].forEach((id) => (els[id] = $(id)));

  els.hostBadge.textContent = hostType === Office.HostType.Word ? "Word" : hostType === Office.HostType.Excel ? "Excel" : String(hostType);

  loadSettings();
  bindEvents();
  withBusy(refreshModels);
});
